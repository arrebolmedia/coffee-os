# Auto‑Dev Starter

## Requisitos
- Node 20 + pnpm
- Python 3.10+ (para aider)
- Docker (para OpenHands)
- VS Code con extensión Continue (opcional)

## Quickstart
```bash
corepack enable
pnpm i
pnpm dlx playwright install --with-deps
```

### aider (opcional)
```bash
pip install aider-chat
aider  # usa .aider.conf.yml
```

### OpenHands
```bash
export GIT_CLONE_URL=https://github.com/tu-org/tu-repo.git
export OPENAI_API_KEY=sk-***
docker compose up -d
```

### GitHub Actions
- Sube `.github/workflows/*` al repo y activa branch protection y secrets necesarios.
