export const calcTotal=(cents:number,{tipPct=0}:{tipPct?:number}={})=>Math.round(cents*(1+tipPct/100));
