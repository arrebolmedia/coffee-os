import { describe, it, expect } from 'vitest'
import { calcTotal } from './index'
describe('calcTotal', () => {
  it('returns a number', () => {
    expect(typeof calcTotal(100,{tipPct:10})).toBe('number')
  })
})
