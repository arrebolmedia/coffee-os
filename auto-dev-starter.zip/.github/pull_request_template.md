## Resumen
¿Qué cambia y por qué?

## Plan
- [ ] Paso 1 …
- [ ] Paso 2 …

## Pruebas
- [ ] Unit ✅
- [ ] E2E ✅

## Checklist
- [ ] Añadí/actualicé tests
- [ ] Cobertura ≥ 90% del módulo tocado
- [ ] No secrets, diffs < 400 LOC
