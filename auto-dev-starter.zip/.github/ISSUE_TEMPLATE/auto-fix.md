### Bug/Feature
Describe en 1-2 líneas.

### Repro
Pasos exactos o test que debe fallar.

### Criterio de aceptación
- [ ] Test rojo inicial
- [ ] Test verde tras fix
- [ ] Cobertura ≥ 90% en módulo tocado

### Scope
- Paquetes/dirs permitidos:
- Archivos clave de contexto:
